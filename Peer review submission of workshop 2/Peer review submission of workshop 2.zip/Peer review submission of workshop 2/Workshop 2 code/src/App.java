import controller.Act;

public class App {

    public static void main(String[] args) throws Exception {

    	Act act = new Act();
    	act.readChoice();

    }

}
